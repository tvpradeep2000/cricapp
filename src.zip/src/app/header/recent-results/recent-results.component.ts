import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recent-results',
  templateUrl: './recent-results.component.html',
  styleUrls: ['./recent-results.component.css']
})
export class RecentResultsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
