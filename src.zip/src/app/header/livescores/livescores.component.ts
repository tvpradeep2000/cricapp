import { Component, OnInit } from '@angular/core';
import { HomeService } from 'src/app/services/home.service';

@Component({
  selector: 'app-livescores',
  templateUrl: './livescores.component.html',
  styleUrls: ['./livescores.component.css']
})
export class LivescoresComponent implements OnInit {
  liveScores: any;
  constructor(private ts:HomeService) { }

  ngOnInit(): void {
    // this.ts.getLiveMatches().subscribe((data:any)=>{
    //   this.liveMatches = data;
    // })
    this.fetchLiveScores();
  }

  // fetchLiveScores(): void {
  //   this.ts.getLiveMatches().subscribe(
  //     (data) => {
  //       this.liveScores = data.matches;
  //     },
  //     (error) => {
  //       console.error('Error fetching live scores', error);
  //     }
  //   );
  // }

  fetchLiveScores(): void {
    this.ts.getLiveMatches().subscribe(
      (res) => {
        console.log('API Response:', res); // Log the response for debugging
        this.liveScores = res.data;
        console.log(this.liveScores)
      },
      (error) => {
        console.error('Error fetching live scores', error);
      }
    );
  }


}
